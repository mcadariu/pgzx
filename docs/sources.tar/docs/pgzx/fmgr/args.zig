const std = @import("std");
const pg = @import("pgzx_pgsys");

const err = @import("../err.zig");
const datum = @import("../datum.zig");

/// Index function argument type.
pub fn Arg(comptime T: type, comptime argNum: u32) type {
    return struct {
        const Self = @This();

        /// Reads the argument from the PostgreSQL function call information.
        pub inline fn read(fcinfo: pg.c.FunctionCallInfo) !T {
            return readArg(T, fcinfo, argNum);
        }

        /// Returns the type of the argument.
        pub inline fn getType() type {
            return ArgType(T);
        }
    };
}

/// The type of a function argument.
pub fn ArgType(comptime T: type) type {
    return struct {
        const Self = @This();

        /// Computes the indexed type of a function argument.
        pub inline fn getForIndex(self: Self, argNum: u32) type {
            _ = self;
            return Arg(T, argNum);
        }

        pub inline fn isCallInfo() bool {
            return T == pg.c.FunctionCallInfo;
        }

        pub inline fn consumesArgument() bool {
            return !Self.isCallInfo();
        }

        /// Reads the indexed function argument.
        pub inline fn read(fcinfo: pg.c.FunctionCallInfo, argNum: u32) !T {
            return readArg(T, fcinfo, argNum);
        }
    };
}

inline fn readArgType(comptime T: type) type {
    if (T == pg.c.FunctionCallInfo) {
        return T;
    }
    return datum.findConv(T).Type;
}

/// Reads a postgres function call argument as a given type.
fn readArg(comptime T: type, fcinfo: pg.c.FunctionCallInfo, argNum: u32) !readArgType(T) {
    if (T == pg.c.FunctionCallInfo) {
        return fcinfo;
    }
    const converter = comptime datum.findConv(T);
    const oid = try err.wrap(pg.c.get_fn_expr_argtype, .{ fcinfo.*.flinfo, @as(c_int, @intCast(argNum)) });
    const ndatum = try mustGetArgNullable(fcinfo, argNum);
    return converter.fromNullableDatumWithOID(ndatum, oid);
}

fn readOptionalArg(comptime T: type, fcinfo: pg.c.FunctionCallInfo, argNum: u32) !?T {
    if (isNullArg(fcinfo, argNum)) {
        return null;
    }
    return readArg(T, fcinfo, argNum);
}

pub inline fn mustGetArgNullable(fcinfo: pg.c.FunctionCallInfo, argNum: u32) !pg.c.NullableDatum {
    if (fcinfo.*.nargs < argNum) {
        return error.NotEnoughArguments;
    }
    return fcinfo.*.args()[argNum];
}

pub inline fn mustGetArgDatum(fcinfo: pg.c.FunctionCallInfo, argNum: u32) !pg.c.Datum {
    if (isNullArg(fcinfo, argNum)) {
        return error.ArgumentIsNull;
    }
    return getArgDatum(fcinfo, argNum);
}

pub inline fn getArgDatum(fcinfo: pg.c.FunctionCallInfo, argNum: u32) pg.c.Datum {
    return fcinfo.*.args()[argNum].value;
}

pub inline fn isNullArg(fcinfo: pg.c.FunctionCallInfo, argNum: u32) bool {
    return fcinfo.*.args()[argNum].isnull;
}
